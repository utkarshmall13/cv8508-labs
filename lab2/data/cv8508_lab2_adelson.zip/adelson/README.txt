Checker-shadow illusion (Edward H. Adelson, 1995; https://persci.mit.edu/gallery/checkershadow, "may be reproduced and distributed freely").
This copy is a vector re-creation of the illusion (Wikimedia Commons file Checker_shadow_illusion.svg) rendered at 512x390.
adelson.json: probe boxes (x0, y0, x1, y1 as fractions of width and height) and ratios:
  albedo_gt = true albedo ratio of the pair (same paint = 1; light paint over dark paint measured on the two unshadowed tiles)
  pixels    = ratio of the (linear-light) pixel values
Probes: A dark tile in light, B light tile in shadow, Dlit/Dshadow the same dark paint in light and in shadow, Llit a light tile in light.
