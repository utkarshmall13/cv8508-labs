Intrinsic Images in the Wild (IIW) subset for CV8508 Lab 2.
Source: Bell, Bala and Snavely, 'Intrinsic Images in the Wild', ACM SIGGRAPH 2014, http://intrinsic.cs.cornell.edu
Images are downsized (longest side 160 px) and the human judgments are converted to a simple json format:
  points: [x, y] as fractions of width and height; comparisons: [i, j, darker, weight],
  darker 0 = equal reflectance, 1 = point i darker, 2 = point j darker; weight = human confidence.
Split: deterministic hash of the image id (about 85/15). Use the original dataset terms and per-image licences if you redistribute.
