CV8508 Lab 1 - human faces (positives for "face vs not-face")
train/ 5000 crops, val/ 500 crops, 112x112 JPEG, tightly cropped and aligned faces.
Source: UTKFace (Zhang, Song, Qi, CVPR 2017), from the GitHub mirror anasserhussien/EthnicityRecognition-UTKFaces, random sample (seed 0).
Terms: UTKFace is for non-commercial research/education use. Original images were collected from the web.
