CV8508 Lab 1 - optional upper bound
face/  400 pareidolic face crops (112x112, same cropping rule as fit_test) from the TRAIN split of Faces in Things (Hamilton et al., ECCV 2024).
Use only for the "fine-tune on the thing itself" extension; never evaluate on these.
