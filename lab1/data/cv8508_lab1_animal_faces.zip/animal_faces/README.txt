CV8508 Lab 1 - animal faces (cat / dog / wild)
train/{cat,dog,wild}/ 700 each (2100), val/{cat,dog,wild}/ 150 each (450), 112x112 JPEG (centre 80% of the original 512x512 head-centred image).
Source: AFHQ (Choi et al., StarGAN v2, CVPR 2020), CC BY-NC 4.0, from the GitHub mirror harishnr93/CNN_Image_Classification, random sample (seed 0).
Stand-in for AnimalWeb, which Hamilton et al. (ECCV 2024) used for their animal-face stage.
