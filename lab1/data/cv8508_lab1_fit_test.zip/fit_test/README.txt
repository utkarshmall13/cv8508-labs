CV8508 Lab 1 - test subset of "Faces in Things" (Hamilton et al., ECCV 2024)
fit_test.csv       one row per image: boxes ([x, y, w, h] for every annotated pareidolic face), face_crop, nonface_crop, neg_square, person_or_creature, hard_to_spot, accident_or_design, url (the image on the public mirror)
crops/face/        927 positives: square crop (1.15 x the longer side of the primary face box), 112x112
crops/nonface/     927 negatives: a crop that overlaps no face box (<=2% of its area), similar size, no white padding, 112x112
All images come from the TEST split of the dataset. NSFW-flagged and duplicate-flagged images were removed, as were images whose primary face box is smaller than 40 px or whose crop is mostly white padding.
Source: images fetched from the GitHub mirror 3lbom/pareidolia using the URLs in the official metadata (github.com/mhamilton723/FacesInThings). The dataset derives from LAION-5B web images; copyright stays with the original owners. Coursework use only.
Caveat: images are not exhaustively annotated, so a "non-face" crop can contain a face that nobody drew a box around.
